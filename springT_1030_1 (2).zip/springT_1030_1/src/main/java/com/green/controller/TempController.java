package com.green.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.green.domain.Criteria;
import com.green.domain.ReplyVO;
import com.green.mapper.ReplyMapper;
import com.green.service.ReplyService;

import lombok.Setter;

@Controller
@RequestMapping("/reply")
public class TempController {
	@Setter(onMethod_=@Autowired)
	private ReplyService service;
	
	@GetMapping("/list")
	public String list(Model model) {
		service.getList(new Criteria(), 60L).forEach(i -> System.out.println(i + " "));
		model.addAttribute("replies", service.getList(new Criteria(), 60L));
		return "/reply/list";
	}
	
	@GetMapping("/register")
	public String register(Model model) {
		return "/reply/register";
	}
	
	@PostMapping("/register")
	public String insert(Model model, ReplyVO reply) {
		service.register(reply);
		return "redirect:/reply/list";
	}

}
