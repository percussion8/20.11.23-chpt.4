package com.green.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.green.domain.SampleDTO;
import com.green.domain.SampleDTOList;
import com.green.domain.SampleVO;
import com.green.domain.TodoDTO;

import lombok.extern.slf4j.Slf4j;



@Controller
@RequestMapping("/sample/*")
@Slf4j
public class SampleController {
	
	@RequestMapping("")
	public void basic() {
		log.info("basic.........");
	}
	
	@RequestMapping(value="/basic", method= {RequestMethod.GET,
			RequestMethod.POST})
	public void basicGet() {
		log.info("basic get ............");
	}
	
	@GetMapping("/basicOnlyGet")
	public void basicGet2() {
		log.info("basic get only get.........");
	}
	@PostMapping("/basicOnlyGet")
	public void basicGet3() {
		log.info("basic post only post.........");
	}
	
	
	@GetMapping("/ex01")
	public String ex01(SampleDTO dto) {
		log.info("" +dto);
		return "ex01";
	}
	@GetMapping("/ex02")
	public String ex02(@RequestParam("name") String i , 
			@RequestParam("age") int j) {
		log.info("name"+ i);
		log.info("age"+j);
		return "ex02";
	}
	@GetMapping("/ex02List")
	public String ex02List(@RequestParam("ids") ArrayList<String> ids) {
		log.info("ids:" + ids);
		return "ex02List";
	}
	//url �Է��� ids=111&ids=222&ids=333
	
	@GetMapping("/ex02Array")
	public String ex02Array(@RequestParam("ids") String[] ids) {
		log.info("array ids: "+ Arrays.toString(ids));
		return "ex02Array";
	}
	
	@GetMapping("/ex02Bean")
	public String ex02Bean(SampleDTOList list) {
		log.info("list dto : " +list);
		return "ex02Bean";
	}
	
	//@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		binder.registerCustomEditor(java.util.Date.class, 
				new CustomDateEditor(dateFormat, false));
	}
	@RequestMapping("/ex03")
	public String ex03(TodoDTO todo) {
		log.info("todo: "+ todo);
		return "ex03";
	}
	
	
	@RequestMapping("/ex04")
	public String ex04(SampleDTO dto, @ModelAttribute("page") int page) {
		log.info("dto: "+ dto);
		log.info("page:" +page);
		
		return "/sample/ex04";
	}
	
	@GetMapping("/ex05")
	public void  ex05() {
		log.info("/ex05...."); //에러 발생함 
	}
	
	@GetMapping("/ex05_1")
	public String  ex05_1() {
		log.info("/ex05_1...."); //에러 발생함 
		return "a";
	}
	@GetMapping("/ex06")
	public @ResponseBody SampleDTO ex06() {
		log.info("/ex06......");
		SampleDTO dto = new SampleDTO();
		dto.setAge(10);
		dto.setName("홍길동");
		return dto;
	}
	@GetMapping("/ex06_1")
	public @ResponseBody SampleVO ex111() {
		log.info("ex06_1..........");
		SampleVO a = new SampleVO();
		a.setEng(80);
		a.setKorea(70);
		a.setMath(90);
		int eng = a.getEng();
		int korea = a.getKorea();
		int math = a.getMath();
		a.setId(5);
		a.setName("홍길동");
		a.setTotal(eng +korea+ math);
		a.setAvg((eng +korea+ math)/3.0f);
		return a;
	}
}
